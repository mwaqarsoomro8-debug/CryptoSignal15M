package com.example.cryptosignal15m

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF141D30)
private val TextMain = Color(0xFFEDF3FF)
private val Muted = Color(0xFF9AA8C1)
private val Green = Color(0xFF38D996)
private val Red = Color(0xFFFF687D)
private val Yellow = Color(0xFFF3C969)
private val Blue = Color(0xFF7BA7FF)

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double, val closeTime: Long)
data class SignalResult(
    val side: String, val strength: Int, val price: Double, val rsi: Double,
    val ema9: Double, val ema21: Double, val atr: Double, val reasons: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CryptoSignalApp() }
    }
}

@Composable
fun CryptoSignalApp() {
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var capital by remember { mutableStateOf("100") }
    var riskPct by remember { mutableStateOf("0.5") }
    var leverage by remember { mutableStateOf("3") }
    var result by remember { mutableStateOf<SignalResult?>(null) }
    var status by remember { mutableStateOf("Ready · 15-minute candles") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Bg, surface = Panel, onBackground = TextMain,
        onSurface = TextMain, secondary = Green
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Crypto Signal 15M", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextMain)
                Text("Futures signal assistant · no automatic orders", color = Muted, fontSize = 14.sp)
                CardBox {
                    Text("Market settings", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    OutlinedTextField(
                        value = symbol, onValueChange = { symbol = it.uppercase(Locale.US).filter { ch -> ch.isLetterOrDigit() }.take(20) },
                        label = { Text("Symbol (e.g. BTCUSDT)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = capital, onValueChange = { capital = it.filter { c -> c.isDigit() || c == '.' }.take(12) },
                            label = { Text("Account USDT") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = riskPct, onValueChange = { riskPct = it.filter { c -> c.isDigit() || c == '.' }.take(5) },
                            label = { Text("Risk %") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = leverage, onValueChange = { leverage = it.filter(Char::isDigit).take(3) },
                        label = { Text("Leverage (risk calculator only)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            error = null
                            if (symbol.isBlank()) { error = "Enter a symbol such as BTCUSDT."; return@Button }
                            busy = true
                            status = "Fetching public market data…"
                            scope.launch {
                                try {
                                    val candles = withContext(Dispatchers.IO) { fetchCandles(symbol) }
                                    result = analyze(candles)
                                    status = "Updated from public exchange data · 15m"
                                } catch (e: Exception) {
                                    error = e.message ?: "Could not fetch market data."
                                    status = "Data unavailable"
                                } finally { busy = false }
                            }
                        },
                        enabled = !busy, modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Loading…" else "Fetch data & analyze") }
                    Text(status, color = Muted, fontSize = 12.sp)
                    error?.let { Text(it, color = Red, fontSize = 13.sp) }
                }

                result?.let { r ->
                    val sideColor = when (r.side) { "BUY" -> Green; "SELL" -> Red; else -> Yellow }
                    CardBox {
                        Text("Latest closed 15M candle", color = Muted, fontSize = 13.sp)
                        Text(r.side, color = sideColor, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text(if (r.side == "WAIT") "Conditions are mixed; no trade setup." else "Rule checks aligned: ${r.strength}% score (not probability).", color = Muted)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Metric("Price", fmt(r.price))
                            Metric("Signal score", "${r.strength}%")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Metric("RSI 14", fmt(r.rsi))
                            Metric("EMA 9 / 21", "${fmt(r.ema9)} / ${fmt(r.ema21)}")
                        }
                        Text("Signal reasons", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        r.reasons.forEach { Text("• $it", color = Muted, fontSize = 14.sp) }
                    }
                    val capitalValue = capital.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                    val riskValue = (riskPct.toDoubleOrNull() ?: 0.5).coerceIn(0.1, 5.0)
                    val lev = (leverage.toDoubleOrNull() ?: 1.0).coerceIn(1.0, 125.0)
                    val entry = r.price
                    val stopDistance = r.atr * 1.5
                    val isTrade = r.side != "WAIT" && stopDistance > 0 && entry > 0
                    val sl = if (!isTrade) Double.NaN else if (r.side == "BUY") entry - stopDistance else entry + stopDistance
                    val tp = if (!isTrade) Double.NaN else if (r.side == "BUY") entry + stopDistance * 1.5 else entry - stopDistance * 1.5
                    val riskCash = capitalValue * riskValue / 100.0
                    val qty = if (isTrade) riskCash / stopDistance else 0.0
                    val notional = qty * entry
                    val margin = notional / lev
                    CardBox {
                        Text("Indicative trade plan", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Text("Entry: ${if (isTrade) fmt(entry) else "WAIT"}", fontSize = 16.sp)
                        Text("Take profit: ${if (isTrade) fmt(tp) else "—"}", color = Green, fontSize = 16.sp)
                        Text("Stop loss: ${if (isTrade) fmt(sl) else "—"}", color = Red, fontSize = 16.sp)
                        Divider(color = Color(0xFF27334B))
                        Text("Planned risk: ${fmt(riskCash)} USDT (${fmt(riskValue)}% of account)")
                        Text("Position size: ${fmt(qty, 6)} units · notional ${fmt(notional)} USDT")
                        Text("Estimated initial margin at ${fmt(lev)}x: ${fmt(margin)} USDT (excludes fees and maintenance margin)", color = Muted, fontSize = 13.sp)
                        Text("Risk sizing assumes entry-to-stop loss and does not predict liquidation. Actual fill, fees, slippage and exchange rules can change results.", color = Yellow, fontSize = 12.sp)
                    }
                }
                CardBox {
                    Text("How the signal works", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text("• EMA 9 above EMA 21 + RSI above 50 + volume above its 20-candle average → BUY check.", color = Muted)
                    Text("• EMA 9 below EMA 21 + RSI below 50 + volume above its 20-candle average → SELL check.", color = Muted)
                    Text("• Otherwise WAIT. Stop distance = 1.5 × ATR(14); target = 1.5 × stop distance.", color = Muted)
                    Text("This is a prototype for learning and paper trading, not financial advice. No exchange account or order placement is connected.", color = Yellow, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun RowScope.Metric(label: String, value: String) {
    Column(
        Modifier.weight(1f).background(Color(0xFF0D1425), RoundedCornerShape(10.dp)).padding(12.dp)
    ) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

private fun fetchCandles(symbol: String): List<Candle> {
    val safe = symbol.uppercase(Locale.US)
    val url = URL("https://fapi.binance.com/fapi/v1/klines?symbol=$safe&interval=15m&limit=200")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 12000
        readTimeout = 12000
        setRequestProperty("User-Agent", "CryptoSignal15M/1.0")
    }
    try {
        val code = connection.responseCode
        if (code !in 200..299) throw IllegalStateException("Exchange returned HTTP $code. Check symbol or try later.")
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONArray(body)
        val out = mutableListOf<Candle>()
        for (i in 0 until arr.length()) {
            val k = arr.getJSONArray(i)
            out += Candle(k.getLong(0), k.getString(1).toDouble(), k.getString(2).toDouble(),
                k.getString(3).toDouble(), k.getString(4).toDouble(), k.getString(5).toDouble(), k.getLong(6))
        }
        val now = System.currentTimeMillis()
        return out.filter { it.closeTime < now }.also {
            if (it.size < 40) throw IllegalStateException("Not enough closed candles returned.")
        }
    } finally { connection.disconnect() }
}

private fun analyze(candles: List<Candle>): SignalResult {
    val closes = candles.map { it.close }
    val volumes = candles.map { it.volume }
    val e9 = ema(closes, 9)
    val e21 = ema(closes, 21)
    val rsiValues = rsi(closes, 14)
    val atrValues = atr(candles, 14)
    val i = candles.lastIndex
    val bullEma = e9[i] > e21[i]
    val bearEma = e9[i] < e21[i]
    val bullRsi = rsiValues[i] > 50.0
    val bearRsi = rsiValues[i] < 50.0
    val volAvg = volumes.takeLast(20).average()
    val volumeOk = volumes[i] > volAvg
    val bull = listOf(bullEma, bullRsi, volumeOk).count { it }
    val bear = listOf(bearEma, bearRsi, volumeOk).count { it }
    val side = when { bull == 3 -> "BUY"; bear == 3 -> "SELL"; else -> "WAIT" }
    val score = when (side) { "BUY" -> bull * 100 / 3; "SELL" -> bear * 100 / 3; else -> max(bull, bear) * 100 / 3 }
    val reasons = listOf(
        "EMA 9 ${if (bullEma) "above" else "below"} EMA 21",
        "RSI ${fmt(rsiValues[i])} ${if (bullRsi) "above" else "at/below"} 50",
        "Volume ${if (volumeOk) "above" else "not above"} its 20-candle average"
    )
    return SignalResult(side, score, closes[i], rsiValues[i], e9[i], e21[i], atrValues[i], reasons)
}

private fun ema(values: List<Double>, period: Int): List<Double> {
    val out = MutableList(values.size) { Double.NaN }
    if (values.size < period) return out
    var prev = values.take(period).average()
    out[period - 1] = prev
    val k = 2.0 / (period + 1)
    for (i in period until values.size) {
        prev = values[i] * k + prev * (1 - k)
        out[i] = prev
    }
    return out
}

private fun rsi(values: List<Double>, period: Int): List<Double> {
    val out = MutableList(values.size) { Double.NaN }
    if (values.size <= period) return out
    var gain = 0.0
    var loss = 0.0
    for (i in 1..period) {
        val d = values[i] - values[i - 1]
        gain += max(d, 0.0); loss += max(-d, 0.0)
    }
    gain /= period; loss /= period
    out[period] = if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1 + gain / loss)
    for (i in period + 1 until values.size) {
        val d = values[i] - values[i - 1]
        gain = (gain * (period - 1) + max(d, 0.0)) / period
        loss = (loss * (period - 1) + max(-d, 0.0)) / period
        out[i] = if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1 + gain / loss)
    }
    return out
}

private fun atr(cs: List<Candle>, period: Int): List<Double> {
    val tr = cs.mapIndexed { i, c ->
        if (i == 0) c.high - c.low
        else max(c.high - c.low, max(abs(c.high - cs[i - 1].close), abs(c.low - cs[i - 1].close)))
    }
    return tr.indices.map { i -> if (i < period - 1) Double.NaN else tr.subList(i - period + 1, i + 1).average() }
}

private fun fmt(value: Double, digits: Int = 4): String {
    if (!value.isFinite()) return "—"
    return String.format(Locale.US, "%,.${digits}f", value)
}

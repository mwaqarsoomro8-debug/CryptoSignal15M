# Crypto Signal 15M — Android starter project

A native Android (Kotlin + Jetpack Compose) starter app that fetches public Binance USDⓈ-M Futures 15-minute candles and displays a rule-based BUY / SELL / WAIT signal, indicative Entry / TP / SL, risk-based position sizing, and a leverage-based estimated initial margin.

## Important limitations
- This project does **not** place orders and does not connect to a user account.
- Signals are educational rules, not a proven trading strategy or a probability of profit.
- Risk sizing, fees, margin and liquidation are simplified. Actual exchange execution, slippage, funding, maintenance margin and symbol rules are not modeled.
- Uses Binance public Futures market data by default. The exchange endpoint can be replaced in `MainActivity.kt`.
- This archive contains project source, not a compiled APK. The APK should only be claimed after building and testing it.

## Build with Android Studio
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `CryptoSignal15M-Android` folder.
4. Allow Gradle sync to finish. Use JDK 17 (Android Studio's embedded JDK is usually suitable).
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run** to install and launch the app.

## Build a debug APK
From the project root, with Android SDK and JDK 17 installed:
- Windows: `gradlew.bat assembleDebug` (if you have generated/downloaded the Gradle wrapper), or use Android Studio **Build > Build APK(s)**.
- macOS/Linux: `./gradlew assembleDebug` (if the Gradle wrapper is present), or use Android Studio **Build > Build APK(s)**.

The output from a successful Android Studio build is normally:
`app/build/outputs/apk/debug/app-debug.apk`

This starter archive intentionally does not bundle a Gradle wrapper JAR. Android Studio can import the Gradle project and use its Gradle tooling; alternatively generate a wrapper from an installed Gradle 8.9 installation.

## Signal logic
- 15-minute closed candles only.
- BUY if EMA 9 > EMA 21, RSI(14) > 50, and latest volume is above the 20-candle average.
- SELL if EMA 9 < EMA 21, RSI(14) < 50, and latest volume is above the 20-candle average.
- Otherwise WAIT.
- Stop distance = 1.5 × ATR(14); target distance = 1.5 × stop distance.
- Position quantity estimate = account risk amount / entry-to-stop distance.

## Security
No API keys or exchange secrets are required or requested. Do not add withdrawal permissions or paste exchange secrets into the app.
